$(document).ready(function(){
  $('#toggleButton').click(function(){
    $('#disclaimer').slideToggle("slow");
  });
});