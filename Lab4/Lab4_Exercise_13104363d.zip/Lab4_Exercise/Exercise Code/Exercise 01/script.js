$(document).ready(function(){
  $('<Replace this with the right selector>').css('background-color','#dddddd');
});